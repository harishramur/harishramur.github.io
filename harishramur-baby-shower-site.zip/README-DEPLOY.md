# Baby Shower Website

This folder is designed to be copied into the existing `harishramur.github.io` repository without replacing the current homepage.

## Repository path

Copy the entire `baby-shower` folder to:

`harishramur.github.io/baby-shower/`

The existing root `index.html` remains unchanged.

## Live URL after upload

If GitHub Pages is already serving the `patch-2` branch, the invitation will be available at:

`https://harishramur.github.io/baby-shower/`

## Included

- `index.html` — responsive invitation page
- `style.css` — traditional cream/gold/pink visual theme
- `script.js` — countdown + Add to Calendar
- `invitation.jpg` — the supplied invitation artwork

The venue button opens Google Maps using the venue/address from the invitation card.
